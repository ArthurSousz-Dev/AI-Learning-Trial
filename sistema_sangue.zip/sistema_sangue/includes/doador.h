#ifndef DOADOR_H
#define DOADOR_H

typedef struct Doador {
    int id;
    char nome[100];
    char cpf[15];
    char tipoSanguineo[5]; // A+, B-, O+, AB+, etc.
    char telefone[20];
    char ultima_doacao[50];
    int total_doacoes;
    char apto[4]; // "sim" ou "nao"
    struct Doador *prox;
} Doador;

typedef struct elemento {
    Doador dados;
    struct elemento* prox;
} Elemento;

typedef Elemento* Lista; 

Lista* criar_lista();
int cadastrarDoador(Lista *l, Doador dados);
void listarDoadores(Lista *l);
int registrarDoacao(Lista *l, int id);
void listarAptos(Lista *l);
void buscarPorTipo(Lista *l, const char *tipo);
void verificarEstoque(Lista *l);
void salvarEmArquivo(Lista *l);
void carregarDeArquivo(Lista *l);
void liberarLista(Lista *l);

void recuperarDoadoresInativos(Lista *l); //funcao extra que identifica doadores que estao a muito tempo sem doar sangue e notifica o sistema dos mesmos

void atualizarAptidao(Lista *l); //funcao para atualizar a aptidao do doador depois de algum tempo sem usar o programa
int diasPassados(const char *dataStr); /*funcao que usa o time.h para calcular os dias passados 
(importante para a funcao de recuperar doadores depois de um certo periodo e outras funcoes)*/

#endif