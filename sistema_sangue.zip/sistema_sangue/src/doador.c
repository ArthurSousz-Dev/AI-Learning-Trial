#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "doador.h"

// Ajustado o nome para criar_lista (igual estava no main)
Lista* criar_lista() {
    Lista* l = (Lista*) malloc(sizeof(Lista));
    if (l != NULL)
        *l = NULL;
    return l;
}

void liberarLista(Lista *l) {
    if (l != NULL) {
        Elemento* atual;
        while ((*l) != NULL) {
            atual = *l;
            *l = (*l)->prox;
            free(atual);
        }
        free(l);
    }
}

int diasPassados(const char *dataStr) {
    if (strcmp(dataStr, "00/00/0000") == 0) return 9999;
    
    int dia, mes, ano;
    if (sscanf(dataStr, "%d/%d/%d", &dia, &mes, &ano) != 3) return 0;
    struct tm data_doacao = {0};
    data_doacao.tm_mday = dia;  //guarda dia atual do mes
    data_doacao.tm_mon = mes - 1; // guarda mes 
    data_doacao.tm_year = ano - 1900; //guarda ano a partir subtraindo de 1900 que seria o inicio 
    time_t tempo_doacao = mktime(&data_doacao);
    time_t tempo_atual = time(NULL);
    double segundos = difftime(tempo_atual, tempo_doacao);
    return (int) (segundos / (60 * 60 * 24));
}

void atualizarAptidao(Lista *l) {
    Elemento *atual = *l;
    while (atual != NULL) {
        if (diasPassados(atual->dados.ultima_doacao) >= 90) {
            strcpy(atual->dados.apto, "sim");
        } else {
            strcpy(atual->dados.apto, "nao");
        }
        atual = atual->prox;
    }
}

int cadastrarDoador(Lista *l, Doador dados) {
    if (l == NULL)
        return 0;

    Elemento *buscar_cpf = *l;
    while (buscar_cpf != NULL) {
        if (strcmp(buscar_cpf->dados.cpf, dados.cpf) == 0) {
            printf("Erro: CPF ja cadastrado no sistema.\n");
            return 0;
        }
        buscar_cpf = buscar_cpf->prox;
    }

    Elemento *novo = (Elemento*) malloc(sizeof(Elemento));
    if (novo == NULL){
        return 0;
    }
    novo->dados = dados;
    if (*l == NULL || (*l)->dados.id > dados.id) {
        novo->prox = *l;
        *l = novo;
    } else {
        Elemento *anterior = *l;
        Elemento *atual = (*l)->prox;
        
        while (atual != NULL && atual->dados.id < dados.id) {
            anterior = atual;
            atual = atual->prox;
        }
        novo->prox = atual;
        anterior->prox = novo;
    }

    return 1;
}

void listarDoadores(Lista *l) {
    if (*l == NULL) {
        printf("\nNenhum doador cadastrado.\n");
        return;
    }
    printf("\n--- LISTA DE DOADORES ---\n");
    Elemento *atual = *l;
    while (atual != NULL) {
        printf("ID: %d | Nome: %s | Tipo: %s | Doacoes: %d | Apto: %s | Ultima: %s\n", 
               atual->dados.id, atual->dados.nome, atual->dados.tipoSanguineo, 
               atual->dados.total_doacoes, atual->dados.apto, atual->dados.ultima_doacao);
        atual = atual->prox;
    }
}

int registrarDoacao(Lista *l, int id) {
    if (l == NULL || *l == NULL) {
        printf("Erro: Lista invalida ou vazia.\n");
        return 0;
    }
    Elemento *atual = *l;
    while (atual != NULL && atual->dados.id != id) {
        atual = atual->prox;
    }
    if (atual == NULL) {
        printf("Erro: Doador com ID %d nao encontrado.\n", id);
        return 0;
    }
    if (strcmp(atual->dados.apto, "nao") == 0) {
        printf("Operacao negada! O doador nao respeitou o intervalo minimo de 90 dias.\n");
        return 0;
    }
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    sprintf(atual->dados.ultima_doacao, "%02d/%02d/%04d", tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900);
    atual->dados.total_doacoes += 1;
    strcpy(atual->dados.apto, "nao");
    printf("Doacao registrada. doador inapto durante 90 dias.\n");
    return 1;
}

void listarAptos(Lista *l) {
    printf("\n--- DOADORES APTOS PARA DOACAO (HOJE) ---\n");
    Elemento *atual = *l;
    int encontrou = 0;
    while (atual != NULL) {
        if (strcmp(atual->dados.apto, "sim") == 0) {
            printf("ID: %d | Nome: %s | Telefone: %s | Tipo: %s\n", 
                   atual->dados.id, atual->dados.nome, atual->dados.telefone, atual->dados.tipoSanguineo);
            encontrou = 1;
        }
        atual = atual->prox;
    }
    if (!encontrou) printf("Nenhum doador apto no momento.\n");
}

void buscarPorTipo(Lista *l, const char *tipo) {
    printf("\n--- BUSCA POR TIPO SANGUINEO: %s ---\n", tipo);
    Elemento *atual = *l;
    int encontrou = 0;
    while (atual != NULL) {
        if (strcasecmp(atual->dados.tipoSanguineo, tipo) == 0) {
            printf("- %s (Telefone: %s | Apto: %s)\n", atual->dados.nome, atual->dados.telefone, atual->dados.apto);
            encontrou = 1;
        }
        atual = atual->prox;
    }
    if (!encontrou) printf("Nenhum doador encontrado com este tipo sanguineo.\n");
}

void verificarEstoque(Lista *l) {
    int countA = 0, countB = 0, countAB = 0, countO = 0;
    
    Elemento *atual = *l;
    while (atual != NULL) {
        if (strstr(atual->dados.tipoSanguineo, "A") != NULL && strstr(atual->dados.tipoSanguineo, "AB") == NULL) countA += atual->dados.total_doacoes;
        if (strstr(atual->dados.tipoSanguineo, "B") != NULL && strstr(atual->dados.tipoSanguineo, "AB") == NULL) countB += atual->dados.total_doacoes;
        if (strstr(atual->dados.tipoSanguineo, "AB") != NULL) countAB += atual->dados.total_doacoes;
        if (strstr(atual->dados.tipoSanguineo, "O") != NULL) countO += atual->dados.total_doacoes;
        atual = atual->prox;
    }
    
    printf("\n--- Historico de Bolsas de Sangue ---\n");
    printf("Tipo A  : %d bolsas\n", countA);
    printf("Tipo B  : %d bolsas\n", countB);
    printf("Tipo AB : %d bolsas\n", countAB);
    printf("Tipo O  : %d bolsas\n", countO);
}

void salvarEmArquivo(Lista *l) {
    FILE *arquivo = fopen("doadores.bin", "wb");
    if (arquivo == NULL) {
        printf("Erro ao abrir arquivo para salvar.\n");
        return;
    }
    Elemento *atual = *l;
    while (atual != NULL) {
        fwrite(&(atual->dados), sizeof(Doador), 1, arquivo);
        atual = atual->prox;
    }
    fclose(arquivo);
}

void carregarDeArquivo(Lista *l) {
    FILE *arquivo = fopen("doadores.bin", "rb");
    if (arquivo == NULL) return; 
    Doador temp;
    while (fread(&temp, sizeof(Doador), 1, arquivo) == 1) {
        Elemento *novo = (Elemento*) malloc(sizeof(Elemento));
        temp.prox = NULL;
        novo->dados = temp;
        novo->prox = NULL;
        if (*l == NULL) {
            *l = novo;
        } else {
            Elemento *atual = *l;
            while (atual->prox != NULL) {
                atual = atual->prox;
            }
            atual->prox = novo;
        }
    }
    fclose(arquivo);
}

void recuperarDoadoresInativos(Lista *l) {
    printf("\n======================================================\n");
    printf("CAMPANHA DE RECONVOCACAO: DOADORES INATIVOS (+365 DIAS)\n");
    printf("======================================================\n");
    Elemento *atual = *l;
    int encontrou = 0;
    while (atual != NULL) {
        if (atual->dados.total_doacoes > 0 && diasPassados(atual->dados.ultima_doacao) >= 365) {
            printf("Doador: %s\n", atual->dados.nome);
            printf("Telefone: %s\n", atual->dados.telefone);
            printf("Tipo: %s | Ultima Doacao: %s (%d dias atras)\n", 
                   atual->dados.tipoSanguineo, atual->dados.ultima_doacao, diasPassados(atual->dados.ultima_doacao));
            printf("   ---------------------------------------------------\n");
            encontrou = 1;
        }
        atual = atual->prox;
    }
    if (!encontrou) {
        printf("Todos os nossos doadores estao com doacoes recentes no ultimo ano.\n");
    }
}