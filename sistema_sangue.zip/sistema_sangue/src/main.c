#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "doador.h"

int main(){
    Lista* lista_sangue = criar_lista();
    carregarDeArquivo(lista_sangue);
    atualizarAptidao(lista_sangue);

    int opcao, id;
    char tipo_sanguineo[5];
    Doador doador_temp;

    do {
        printf("\n============================================\n");
        printf("SISTEMA DE GESTAO DE DOACAO DE SANGUE\n");
        printf("============================================\n");
        printf("1. Cadastrar Doador\n");
        printf("2. Listar Todos os Doadores\n");
        printf("3. Registrar Nova Doacao\n");
        printf("4. Listar Doadores Aptos (minimo 90 dias)\n");
        printf("5. Buscar Doadores por Tipo Sanguineo\n");
        printf("6. Verificar Estoque por Tipo\n");
        printf("7. Recuperar Doadores Inativos\n");
        printf("0. Salvar e Sair\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);
        getchar(); 

        switch(opcao) {
            case 1:
                printf("\n--- Novo Cadastro ---\n");
                printf("ID do Doador: "); scanf("%d", &doador_temp.id); getchar();
                printf("Nome: "); fgets(doador_temp.nome, 100, stdin); doador_temp.nome[strcspn(doador_temp.nome, "\n")] = 0;
                printf("CPF: "); fgets(doador_temp.cpf, 15, stdin); doador_temp.cpf[strcspn(doador_temp.cpf, "\n")] = 0;
                printf("Tipo Sanguineo (ex: A+, O-): "); fgets(doador_temp.tipoSanguineo, 5, stdin); doador_temp.tipoSanguineo[strcspn(doador_temp.tipoSanguineo, "\n")] = 0;
                printf("Telefone: "); fgets(doador_temp.telefone, 20, stdin); doador_temp.telefone[strcspn(doador_temp.telefone, "\n")] = 0;
                
                strcpy(doador_temp.ultima_doacao, "00/00/0000"); 
                doador_temp.total_doacoes = 0;
                strcpy(doador_temp.apto, "sim");
                doador_temp.prox = NULL;
                
                if (cadastrarDoador(lista_sangue, doador_temp)) {
                    printf("Doador cadastrado com sucesso!\n");
                }
                break;
            case 2:
                listarDoadores(lista_sangue);
                break;
            case 3:
                printf("Digite o ID do doador para registrar doacao: ");
                scanf("%d", &id);
                registrarDoacao(lista_sangue, id);
                break;
            case 4:
                listarAptos(lista_sangue);
                break;
            case 5:
                printf("Digite o tipo sanguineo (ex: AB+): ");
                fgets(tipo_sanguineo, 5, stdin); tipo_sanguineo[strcspn(tipo_sanguineo, "\n")] = 0;
                buscarPorTipo(lista_sangue, tipo_sanguineo);
                break;
            case 6:
                verificarEstoque(lista_sangue);
                break;
            case 7:
                recuperarDoadoresInativos(lista_sangue);
                break;
            case 0:
                salvarEmArquivo(lista_sangue);
                liberarLista(lista_sangue);
                printf("Dados salvos. Encerrando o sistema...\n");
                break;
            default:
                printf("Opcao invalida!\n");
        }
    } while(opcao != 0);

    return 0;
}